Net Script Hook 1.0.1.0 - 1.1.2.0
-------------------------------------------------------------
Net Script Hook - загрузчик .net скриптов для GTA 4.
Если вы не знаете, что это такое - поддержка модуля Script Hook требует практически 90% всех скриптовых модов для Grand Theft Auto IV.

Функция Net Script Hook работает при наличии:
Grand Theft Auto IV с версии 1.0.1.0 до 1.1.2.0
ASI Loader или XLiveLess
Microsoft .NET Framework 4
Microsoft Visual C++ 2010 Redistributable Package
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author`s Email: hazard_x@gmx.net
Author: Hazard
Was added to the site by user: Kolinsasa
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from http://www.gamemodding.net website
Follow us in social networks!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
