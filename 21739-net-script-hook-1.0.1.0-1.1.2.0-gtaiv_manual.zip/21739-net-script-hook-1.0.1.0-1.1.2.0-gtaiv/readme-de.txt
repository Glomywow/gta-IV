Net Script Hook 1.0.1.0 - 1.1.2.0
-------------------------------------------------------------
Net Script Hook - загрузчик .net скриптов для GTA 4.
Если вы не знаете, что это такое - поддержка модуля Script Hook требует практически 90% всех скриптовых модов для Grand Theft Auto IV.

Функция Net Script Hook работает при наличии:
Grand Theft Auto IV с версии 1.0.1.0 до 1.1.2.0
ASI Loader или XLiveLess
Microsoft .NET Framework 4
Microsoft Visual C++ 2010 Redistributable Package
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Email des Autors: hazard_x@gmx.net
Der Autor: Hazard
Auf der Site vom Benutzer hinzugefuegt wurde: Kolinsasa
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website http://www.gamemodding.net heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
